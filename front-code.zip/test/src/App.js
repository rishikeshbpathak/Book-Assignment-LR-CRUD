import { useEffect, useState } from "react";
function App() {
  const [data, setData] = useState([]);
  const [book_title, setBook_title] = useState('')
  const [book_auth, setBook_auth] = useState('')
  const [book_status, setBook_status] = useState('')
  const [book_description, setBook_description] = useState('')
  const [book_addby, setBook_addby] = useState('')
  const [book_assign, setBook_assign] = useState('')

  const [viewBookData, setViewBookData] = useState([]);

  const [editBookId, setEditBookId] = useState('');
  const [editedBookTitle, setEditedBookTitle] = useState('');
  const [editedBookAuth, setEditedBookAuth] = useState('');
  const [editedBookDese, setEditedBookDese] = useState('');
  const [editedBookStatus, setEditedBookStatus] = useState('');

  //-----------------get-data-----------------//
  const callApi = () => {
    fetch("http://127.0.0.1:8000/api/home/", {
      method: "get", // or 'PUT'
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        //console.log(data)
        setData(data.data)
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }
  //-----------------Add-data-----------------//
  const sendData = () => {
    const fromData = new FormData();

    fromData.append("book_title", book_title);
    fromData.append("book_auth", book_auth);
    fromData.append("book_status", 'enable');
    fromData.append("book_description", book_description);
    fromData.append("book_addby", '0');
    fromData.append("book_assign", '0');
    fetch("http://127.0.0.1:8000/api/home/add/", {
      method: "post", // or 'PUT'
      body: fromData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.Status === "success") {
          alert("data uploaded!!")
        } else {
          alert("somthing went wrong")
        }
      })
      .catch((error) => {
        // alert("Error:", error);
        console.log(error);
      });
  }

  const updateData = () => {

    const fromData = new FormData();

    fromData.append("book_id", editBookId);
    fromData.append("book_title", editedBookTitle);
    fromData.append("book_auth", editedBookAuth);
    fromData.append("book_status", editedBookStatus);
    fromData.append("book_description", editedBookDese);
    fetch(`http://127.0.0.1:8000/api/home/edit/${editBookId}?_method=PUT`, {
      method: "post", // or 'PUT'
      body: fromData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.Status === "success") {
          alert("data updated!!")
          window.location.reload();
        } else {
          alert("somthing went wrong")
        }
      })
      .catch((error) => {
        // alert("Error:", error);
        console.log(error);
      });
  }


  const DeleteData = (id) => {
    //console.log(id);
    const fromData = new FormData();
    fetch(`http://127.0.0.1:8000/api/home/delete/${id}?_mehtod=DELETE`, {
      method: "post", // or 'PUT'
      body: fromData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.Status === "success") {
          alert("data Deleted!!")
          window.location.reload();
        } else {
          alert("somthing went wrong")
        }
      })
      .catch((error) => {
        // alert("Error:", error);
        console.log(error);
      });
  }

  const AssignData = (id, val) => {
    //console.log(id, val);
    if (val == '0') {

      const fromData = new FormData();
      fetch(`http://127.0.0.1:8000/api/home/Assign/${id}?_method=PUT`, {
        method: "post", // or 'PUT'
        body: fromData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.Status === "success") {
            alert("Book Assigned!!")
            window.location.reload();
          } else {
            alert("somthing went wrong")
          }
        })
        .catch((error) => {
          // alert("Error:", error);
          console.log(error);
        });
    } else {

      const fromData = new FormData();
      fetch(`http://127.0.0.1:8000/api/home/UnAssign/${id}?_method=PUT`, {
        method: "post", // or 'PUT'
        body: fromData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.Status === "success") {
            alert("Book Un-Assigned!")
            window.location.reload();
          } else {
            alert("somthing went wrong")
          }
        })
        .catch((error) => {
          // alert("Error:", error);
          console.log(error);
        });
    }

  }

  const [userData, setUserData] = useState([]);

  const getUser = () => {
    fetch(`http://127.0.0.1:8000/api/home/user`, {
      method: "get",
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.Status === "success") {
          //console.log(data.data);
          setUserData(data.data)
        } else {
          alert("somthing went wrong")
        }
      })
      .catch((error) => {
        // alert("Error:", error);
        console.log(error);
      });
  }

  const [assingData, setassingData] = useState([]);

  const getAssing = () => {
    fetch(`http://127.0.0.1:8000/api/home/assingData`, {
      method: "get",
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.Status === "success") {
          //console.log(data.data);
          setUserData(data.data)
        } else {
          alert("somthing went wrong")
        }
      })
      .catch((error) => {
        // alert("Error:", error);
        console.log(error);
      });
  }

  // console.log(viewBookData);
  const [bookData, setBookData] = useState();
  const [selectedUserData, setSelectedUserData] = useState();

  const postData = (bookData, selectedUserData) => {
    console.log(bookData);
    console.log(selectedUserData);
    if (bookData.book_assign == 0 && selectedUserData !== null) {
      const url = `http://127.0.0.1:8000/api/home/Assign/?user_Id=${selectedUserData}&book_id=${bookData.id}`;
      console.log(url)
      fetch(url, {
        method: "post",
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.Status === "success") {
            alert("Book Assigned!!")
            window.location.reload();
          } else {
            alert("somthing went wrong")
          }
        })
        .catch((error) => {
          // alert("Error:", error);
          console.log(error);
        });
    }

  }

  const [assignBookData, setAssignBookData] = useState([]);

  const fetchAssignBookData = () => {
    var url = `http://127.0.0.1:8000/api/home/assingData`
    fetch(url, {
      method: "get",
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.Status === "success") {
          setAssignBookData(data.data)
        } else {
          alert("somthing went wrong")
        }
      })
      .catch((error) => {
        // alert("Error:", error);
        console.log(error);
      });
  }

  console.log(assignBookData)


  useEffect(() => {
    callApi();
    getUser();
    fetchAssignBookData()
  }, [])

  return (
    <div className="App">
      <div className="container-fluid border p-2 bg-light">
        <table className="table table-responsive table-bordered table-striped  text-capitalize">
          <thead>
            <tr className="border">
              <td colSpan={5}> <h4>Book List</h4> </td>

              <td className="">  <button type="button" className="btn btn-outline-primary "
                data-bs-toggle="modal" data-bs-target="#AddBookModal">
                Add-Book
              </button></td>
            </tr>
            <tr className="text-center">
              <th>Index</th>
              <th>Title</th>
              <th>Auth</th>
              <th>Description</th>
              <th>Assign</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody className="text-center" id="TableData">
            {data.map((item, index) => {
              // console.log(item)
              return (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{item.book_title}</td>
                  <td>{item.book_auth}</td>
                  <td>{item.book_description}</td>
                  <td>{item.book_assign == "0" ? <button className="btn text-dark btn-sm btn-outline-warning"
                    onClick={() => { setBookData(item) }}
                    data-bs-toggle="modal" data-bs-target="#userModal">Assign</button> :

                    <button className="btn text-dark btn-sm btn-outline-success" onClick={() => { alert('Allredy Assign'); }}>Assign</button>}
                  </td>
                  <td>
                    <button type="button" className="btn btn-sm btn-outline-primary "
                      data-bs-toggle="modal" data-bs-target="#viewModal" onClick={() => { setEditBookId(item.id); setViewBookData(item) }}>
                      Edit
                    </button>
                    <span> </span>
                    <button href="#" className="btn btn-sm btn-danger" onClick={() => { DeleteData(item.id) }}>Delete</button></td>
                </tr>)
            })}
          </tbody>
        </table>
          {/* <table className="table table-responsive table-bordered table-striped  text-capitalize">
            <thead>
              <tr className="border">
                <td colSpan={5}>
                  <h4>Assigned Book List</h4> </td>
              </tr>
              <tr className="text-center">
                <th>Index</th>
                <th>Aassign Book Id</th>
                <th>Aassign User Id</th>
                <th>Assign Status</th>
              </tr>
            </thead>
            <tbody className="text-center" id="TableData">
              {assignBookData.map((item, index) => {
                // console.log(item)
                return (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{item.assign_bookId}</td>
                    <td>{item.assign_userId}</td>
                    <td>
                      <button className="btn btn-sm btn-outline-success" onClick={() => { AssignData(item.id, "1") }}>Un-Assign</button>
                    </td>
                  </tr>)
              })}
            </tbody>
          </table> */}
      
      </div>
      <div className="modal fade" id="AddBookModal" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex="-1"
        aria-labelledby="AddBookModalLabel" aria-hidden="true">
        <div className="modal-dialog modal-lg">
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title fs-5" id="AddBookModalLabel">New-Book </h1>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form className="border p-2">
              <div className="form-group">
                <label className="form-label">
                  Book Title
                </label>
                <input type='text' className="form-control" onChange={(e) => { setBook_title(e.target.value) }} />
              </div>
              <div className="form-group">
                <label className="form-label">
                  Book Auth
                </label>
                <input type='text' className="form-control" onChange={(e) => { setBook_auth(e.target.value) }} />
              </div>

              <div className="form-group">
                <label className="form-label">
                  Book -Description
                </label>
                <textarea className="form-control" onChange={(e) => { setBook_description(e.target.value) }}> </textarea>
                <input type='hidden' className="form-control" defaultValue={"enable"} onChange={(e) => { setBook_status(e.target.value) }} />
                <input type='hidden' className="form-control" defaultValue={"0"} onChange={(e) => { setBook_addby(e.target.value) }} />
                <input type='hidden' className="form-control" defaultValue={"0"} onChange={(e) => { setBook_assign(e.target.value) }} />
              </div>
              <div className="form-group text-center pt-2">
                <input type='button' className="btn btn-success" defaultValue={"Submit"} onClick={() => { sendData() }} />
              </div>
            </form>
          </div>
        </div>
      </div>

      <div className="modal fade" id="viewModal" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex="-1"
        aria-labelledby="viewModalLabel" aria-hidden="true">
        <div className="modal-dialog modal-lg">
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title fs-5" id="viewModalLabel">Edit-Book </h1>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form className="border p-2">
              <div className="form-group">
                <label className="form-label">
                  Book Title
                </label>
                <input type='text' className="form-control" defaultValue={viewBookData.book_title} onChange={(e) => { setEditedBookTitle(e.target.value) }} />
              </div>
              <div className="form-group">
                <label className="form-label">
                  Book Auth
                </label>
                <input type='text' className="form-control" defaultValue={viewBookData.book_auth} onChange={(e) => { setEditedBookAuth(e.target.value) }} />
              </div>

              <div className="form-group">
                <label className="form-label">
                  Book -Description
                </label>
                <textarea className="form-control" defaultValue={viewBookData.book_description} onChange={(e) => { setEditedBookDese(e.target.value) }} />
                <input type='hidden' className="form-control" defaultValue={"enable"} onChange={(e) => { setBook_status(e.target.value) }} />
                <input type='hidden' className="form-control" defaultValue={"0"} onChange={(e) => { setBook_addby(e.target.value) }} />
                <input type='hidden' className="form-control" defaultValue={"0"} onChange={(e) => { setBook_assign(e.target.value) }} />
                <div className="form-group">
                  <label className="form-label">Book Status</label>
                  <select className="form-control" name="bookStatus" id="bookStatus" onChange={(e) => { setEditedBookStatus(e.target.value) }}>
                    <option defaultValue="enable" selected={viewBookData.book_status === 'enable' ? true : null}>Enable</option>
                    <option defaultValue="disable" selected={viewBookData.book_status === 'disable' ? true : null}>Disable</option>
                  </select>
                </div>
              </div>
              <div className="form-group text-center pt-2">
                <input type='button' className="btn btn-success" defaultValue={"UPDATE"} onClick={() => { updateData() }} />
              </div>
            </form>
          </div>
        </div>
      </div>


      <div className="modal fade" id="userModal" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex="-1"
        aria-labelledby="userModalLabel" aria-hidden="true">
        <div className="modal-dialog modal-lg">
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title fs-5"  id="userModalLabel">Assigned-Book </h1>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <br />
            <br />
            <div className="container">
              <form onSubmit={(e) => { e.preventDefault(); }}>
                <input type='text' placeholder="Enter User Name" className="form-control" required onChange={(e) => { setSelectedUserData(e.target.value) }}></input>

                {/* <select class="form-select" aria-label="Default select example" required onChange={(e) => { setSelectedUserData(JSON.parse(e.target.value)) }}>
                  <option defaultValue={''}>Select User</option>
                  {userData.map((item, index) => {
                    // console.log(item)
                    return (
                      <option key={index} value={JSON.stringify(item)}>{item.name}</option>
                    )
                  })}
                </select> */}
                <br />
                <br />
                <button type="submit" className="btn bg-success text-light" onClick={() => (postData(bookData, selectedUserData))} >Submit</button> <span> </span>
                <button type="button" data-bs-toggle="modal" data-bs-target="#userModal" className="btn text-light bg-danger">Cancel</button>
              </form>
            </div>
            <br />
            <br />
          </div>
        </div>
      </div>
    </div>
  );
}
export default App;
