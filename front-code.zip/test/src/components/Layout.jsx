import React from "react";
import { Link, Outlet } from "react-router-dom";

const Layout = () => {
  return (
    <div className="container-fluid">
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark p-2">
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item active border">
              <Link to={"/"} className="nav-link" href="#">
                <span className="sr-only">Book List</span>
              </Link>
            </li>
            <li className="nav-item border">
              <Link to={"/assigned-book"} className="nav-link" href="#">
                Assigned Book
              </Link>
            </li>
          </ul>
        </div>
      </nav>

      <Outlet />
    </div>
  );
};

export default Layout;
