import React, { Component } from 'react';
 
class Show extends Component {
  render() {
    return (
      <div>
        This is Show component.
      </div>
    );
  }
}
 
export default Show;