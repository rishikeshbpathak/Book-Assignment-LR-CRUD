import React, { useEffect, useState } from "react";

const AssignedBook = () => {
  const [assignBookData, setAssignBookData] = useState([]);

  const fetchAssignBookData = () => {
    var url = `http://127.0.0.1:8000/api/home/assingData`;
    fetch(url, {
      method: "get",
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.Status === "success") {
          setAssignBookData(data.data);
        } else {
          alert("somthing went wrong");
        }
      })
      .catch((error) => {
        // alert("Error:", error);
        console.log(error);
      });
  };

  const AssignData = (id, val) => {
    //console.log(id, val);
    if (val == "0") {
      const fromData = new FormData();
      fetch(`http://127.0.0.1:8000/api/home/Assign/${id}?_method=PUT`, {
        method: "post", // or 'PUT'
        body: fromData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.Status === "success") {
            alert("Book Assigned!!");
            window.location.reload();
          } else {
            alert("somthing went wrong");
          }
        })
        .catch((error) => {
          // alert("Error:", error);
          console.log(error);
        });
    } else {
      const fromData = new FormData();
      fetch(`http://127.0.0.1:8000/api/home/UnAssign/${id}?_method=PUT`, {
        method: "post", // or 'PUT'
        body: fromData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.Status === "success") {
            alert("Book Un-Assigned!");
            window.location.reload();
          } else {
            alert("somthing went wrong");
          }
        })
        .catch((error) => {
          // alert("Error:", error);
          console.log(error);
        });
    }
  };

  useEffect(() => {
    fetchAssignBookData();
  }, []);

  return (
    <div>
      <table className="table table-responsive table-bordered table-striped  text-capitalize">
        <thead>
          <tr className="border">
            <td colSpan={5}>
              <h4>Assigned Book List</h4>{" "}
            </td>
          </tr>
          <tr className="text-center">
            <th>Index</th>
            <th>Aassign Book Id</th>
            <th>Aassign User Id</th>
            <th>Assign Status</th>
          </tr>
        </thead>
        <tbody className="text-center" id="TableData">
          {assignBookData.map((item, index) => {
            // console.log(item)
            return (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{item.assign_bookId}</td>
                <td>{item.assign_userId}</td>
                <td>
                  <button
                    className="btn btn-sm btn-outline-success"
                    onClick={() => {
                      AssignData(item.id, "1");
                    }}
                  >
                    Un-Assign
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default AssignedBook;
